<?php
echo "result=OK";